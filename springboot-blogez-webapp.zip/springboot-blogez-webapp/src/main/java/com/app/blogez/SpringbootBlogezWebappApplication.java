package com.app.blogez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootBlogezWebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootBlogezWebappApplication.class, args);
	}

}

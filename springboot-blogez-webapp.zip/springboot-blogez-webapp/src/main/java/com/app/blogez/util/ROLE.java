package com.app.blogez.util;

public enum ROLE {
    ROLE_ADMIN,
    ROLE_GUEST
}
